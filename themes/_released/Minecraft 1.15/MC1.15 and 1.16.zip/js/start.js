function tossStuff(){
	document.getElementById("body-description").innerHTML = 
	'Welcome to Trivial Trivia!</br>'+
	'Select a trivia to play from the buttons below. You can come back to this screen once you complete the selected trivia.'+
	'';
	
}
/* 
Modes = number of bundled trivia.
*/
var mode1Name = "Minecraft 1.15";
var mode2Name = "Minecraft 1.16";
var mode3Name = "none";
var mode4Name = "none";