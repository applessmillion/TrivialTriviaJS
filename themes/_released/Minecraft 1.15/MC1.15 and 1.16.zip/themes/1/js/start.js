function tossStuff(){
	document.getElementById("body-description").innerHTML = 
	'21 questions, 12 seconds to answer each one! This trivia quizzes you on the features and changes of the 1.16 update for Minecraft. '+
	'Questions and answers will not detail any differences between Bedrock and Java editions of the game.';
	
}
var externalMusic = "https://www.newgrounds.com/audio/listen/984757";
var modes = 1;