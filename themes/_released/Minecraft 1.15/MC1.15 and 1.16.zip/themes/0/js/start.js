function tossStuff(){
	document.getElementById("body-description").innerHTML = 
	'21 questions, 12 seconds to answer each one! This trivia revolves around the features and changes of the 1.15 update for Minecraft. '+
	'Questions and answers should not detail any differences between Bedrock and Java editions of the game.';
	
}

var modes = 0;
var externalMusic = "https://www.newgrounds.com/audio/listen/988465";