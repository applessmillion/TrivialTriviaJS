var ngAPI = {
	"appid":"51305:NfsbPhER",
	"secret":"nwCIPLoGypIvuIKagXnsXQ==",
	"scoreLB":"9863",
	"attemptsLB":"9862",
	"scorehardLB":"none",
	"firstmedal":"61737",
	"secondmedal":"none"
}