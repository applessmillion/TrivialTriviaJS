function tossStuff(){
	document.getElementById("body-description").innerHTML = 
	'Welcome to Trivial Trivia!</br>'+
	'Select a trivia to play from the buttons below. You can come back to this screen once you complete the selected trivia.'+
	'';
	
}
/* 
Modes = number of bundled trivia.
*/
var mode1Name = "Animal Crossing";
var mode2Name = "New Leaf";
var mode3Name = "New Horizons";
var mode4Name = "none";