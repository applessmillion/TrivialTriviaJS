function tossStuff(){
	document.getElementById("body-description").innerHTML = 
	'21 questions, 12 seconds to answer! This short bit of trivia covers bits and pieces of the Metal genre of music. Bands, subgenres, and albums are topics of questions in this trivia. '+
	'Special thanks for <a href="https://www.newgrounds.com/audio/listen/988236" style="font-weight:600">Burn7</a> for allowing his music to be used in this game!';
	
}
