function tossStuff(){
	document.getElementById("body-description").innerHTML = 
	'21 questions, 12 seconds to answer each one! This trivia covers the plot, related media, and setting about the 2020 video game Cyberpunk 2077. '+
	'There are questions that will contain spoilers. If you do not wish for these to be spoiled, do not take this trivia.';
	
}
