function tossStuff(){
	document.getElementById("scoretotal").innerHTML = ""+localStorage.latestscore;
}
