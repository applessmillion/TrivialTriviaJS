function tossStuff(){
	document.getElementById("body-description").innerHTML = 
	'21 questions, 12 seconds to answer each one! This trivia covers the plot, related novels, and setting about the 20th century movie Blade Runner. '+
	'There are questions that will contain spoilers. If you do not wish for these to be spoiled, do not take this trivia.';
	
}
