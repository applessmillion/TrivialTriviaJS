function tossStuff(){
	document.getElementById("body-description").innerHTML = 
	'Many questions, only 12 seconds to answer! This trivia covers game elements and locations of the second Dark Souls game. '+
	'Normal mode has 21 questions, while the Extended mode has 36!</br></br>'+
	'Thanks to KamenRiderStick for suggesting the theme of Dark Souls and Dark Souls II.';
}

var modes = 1;