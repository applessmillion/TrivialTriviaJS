function tossStuff(){
	document.getElementById("body-description").innerHTML = 
	'21 questions, 12 seconds to answer! This trivia covers game elements and locations of the first Dark Souls game. '+
	'Special thanks to JoeyFreezeMusic for audio for this game. The track is named Forest Flashlights. '+
	'Additional thanks to KamenRiderStick for suggesting the theme of Dark Souls and Dark Souls II.';
}
